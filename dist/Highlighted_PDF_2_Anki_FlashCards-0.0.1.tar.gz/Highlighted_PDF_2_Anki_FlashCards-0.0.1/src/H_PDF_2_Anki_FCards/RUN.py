
from H_PDF_2_Anki_FCards import H_PDF_2_Anki_FCards

def run():
    H_PDF_2_Anki_FCards.run()